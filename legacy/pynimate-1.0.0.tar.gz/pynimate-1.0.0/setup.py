# setup.py

from setuptools import setup

setup()