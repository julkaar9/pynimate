# pynimate
python package for statistical data animations 
